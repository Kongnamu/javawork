package data;

public class PrintData {

	public static void main(String[] args) {
		//데이터 다루기 - 코드의 끝은 세미콜론(;)으로 끝냄
        //숫자(상수 - 정해진 수, Constant Number)
		System.out.println(10);   //정수
		System.out.println(2.54); //실수
		System.out.println(2.54 + 10); //덧셈
		
		System.out.println("======================");
		
		//문자 - 쌍따옴표로 감싼다
		System.out.println('A'); //영어 한 문자인 경우는 홀따옴표(')로 감싼다
		System.out.println('가'); //한글 한 문자도 위와 같다
		System.out.println("apple"); //문자열
		System.out.println("사과");
		
	}

}
